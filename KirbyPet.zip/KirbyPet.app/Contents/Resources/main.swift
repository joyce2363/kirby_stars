import Cocoa
import QuartzCore

final class KirbyView: NSView {
    private let normalImage: NSImage
    private let inhaleImage: NSImage
    private let imageLayer = CALayer()
    private var dragStartMouseLocation: NSPoint = .zero
    private var dragStartWindowOrigin: NSPoint = .zero
    private var didDrag = false
    private var isInhaling = false

    var isBouncingEnabled = true {
        didSet {
            if !isInhaling {
                updateBounceAnimation()
            }
        }
    }

    init(frame frameRect: NSRect, normalImage: NSImage, inhaleImage: NSImage) {
        self.normalImage = normalImage
        self.inhaleImage = inhaleImage
        super.init(frame: frameRect)
        self.wantsLayer = true
        self.layer?.backgroundColor = NSColor.clear.cgColor

        let padding: CGFloat = 18
        imageLayer.frame = bounds.insetBy(dx: padding, dy: padding)
        imageLayer.contentsGravity = .resizeAspect
        imageLayer.contents = normalImage
        self.layer?.addSublayer(imageLayer)

        updateBounceAnimation()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func layout() {
        super.layout()
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        let padding: CGFloat = 18
        imageLayer.frame = bounds.insetBy(dx: padding, dy: padding)
        CATransaction.commit()
        if !isInhaling {
            updateBounceAnimation()
        }
    }

    override func acceptsFirstMouse(for event: NSEvent?) -> Bool {
        return true
    }

    /// Returns the screen coordinates of Kirby's open mouth center
    func mouthScreenPoint() -> NSPoint {
        guard let window = self.window else { return .zero }
        let localPoint = NSPoint(x: bounds.width * 0.51, y: bounds.height * 0.44)
        return window.convertPoint(toScreen: localPoint)
    }

    func updateBounceAnimation() {
        imageLayer.removeAnimation(forKey: "idleFloat")
        guard isBouncingEnabled else { return }

        let floatAnim = CABasicAnimation(keyPath: "transform.translation.y")
        floatAnim.fromValue = -6.0
        floatAnim.toValue = 6.0
        floatAnim.duration = 1.15
        floatAnim.autoreverses = true
        floatAnim.repeatCount = .infinity
        floatAnim.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        imageLayer.add(floatAnim, forKey: "idleFloat")
    }

    func playInhaleSequence(onMidInhale: @escaping () -> Void, onComplete: @escaping () -> Void) {
        guard !isInhaling else { return }
        isInhaling = true
        imageLayer.removeAnimation(forKey: "idleFloat")

        // Phase 1: Switch to wide-open mouth sprite and vibrate/stretch as Kirby inhales
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        imageLayer.contents = inhaleImage
        CATransaction.commit()

        let shakeX = CAKeyframeAnimation(keyPath: "transform.translation.x")
        shakeX.values = [0, -3.5, 3.5, -4.0, 4.0, -3.0, 3.0, -2.0, 2.0, 0]
        shakeX.duration = 0.14
        shakeX.repeatCount = 6

        let scaleX = CABasicAnimation(keyPath: "transform.scale.x")
        scaleX.fromValue = 1.0
        scaleX.toValue = 1.14
        scaleX.duration = 0.82
        scaleX.timingFunction = CAMediaTimingFunction(name: .easeOut)

        let scaleY = CABasicAnimation(keyPath: "transform.scale.y")
        scaleY.fromValue = 1.0
        scaleY.toValue = 1.16
        scaleY.duration = 0.82
        scaleY.timingFunction = CAMediaTimingFunction(name: .easeOut)

        let inhaleGroup = CAAnimationGroup()
        inhaleGroup.animations = [shakeX, scaleX, scaleY]
        inhaleGroup.duration = 0.82
        inhaleGroup.fillMode = .forwards
        inhaleGroup.isRemovedOnCompletion = false
        imageLayer.add(inhaleGroup, forKey: "inhaleShake")

        // Trigger window hiding mid-inhale as stars/wind rush into Kirby's mouth
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.42) {
            onMidInhale()
        }

        // Phase 2: Gulp & happy bounce back to normal sprite
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.82) { [weak self] in
            guard let self = self else { return }
            self.imageLayer.removeAnimation(forKey: "inhaleShake")

            CATransaction.begin()
            CATransaction.setDisableActions(true)
            self.imageLayer.contents = self.normalImage
            CATransaction.commit()

            let gulpScaleX = CAKeyframeAnimation(keyPath: "transform.scale.x")
            gulpScaleX.values = [1.30, 0.88, 1.08, 0.97, 1.0]
            gulpScaleX.keyTimes = [0, 0.35, 0.65, 0.85, 1.0]
            gulpScaleX.duration = 0.45

            let gulpScaleY = CAKeyframeAnimation(keyPath: "transform.scale.y")
            gulpScaleY.values = [1.26, 1.15, 0.90, 1.04, 1.0]
            gulpScaleY.keyTimes = [0, 0.35, 0.65, 0.85, 1.0]
            gulpScaleY.duration = 0.45

            let gulpJump = CAKeyframeAnimation(keyPath: "transform.translation.y")
            gulpJump.values = [0, 14, -3, 0]
            gulpJump.keyTimes = [0, 0.4, 0.75, 1.0]
            gulpJump.duration = 0.45

            let gulpGroup = CAAnimationGroup()
            gulpGroup.animations = [gulpScaleX, gulpScaleY, gulpJump]
            gulpGroup.duration = 0.45
            gulpGroup.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
            self.imageLayer.add(gulpGroup, forKey: "gulpBounce")

            onComplete()

            DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) { [weak self] in
                guard let self = self else { return }
                self.isInhaling = false
                self.updateBounceAnimation()
            }
        }
    }

    override func mouseDown(with event: NSEvent) {
        guard let window = self.window else { return }
        dragStartMouseLocation = NSEvent.mouseLocation
        dragStartWindowOrigin = window.frame.origin
        didDrag = false
    }

    override func mouseDragged(with event: NSEvent) {
        guard let window = self.window else { return }
        let currentLocation = NSEvent.mouseLocation
        let dx = currentLocation.x - dragStartMouseLocation.x
        let dy = currentLocation.y - dragStartMouseLocation.y

        if hypot(dx, dy) > 4 {
            didDrag = true
        }

        let newOrigin = NSPoint(
            x: dragStartWindowOrigin.x + dx,
            y: dragStartWindowOrigin.y + dy
        )
        window.setFrameOrigin(newOrigin)
    }

    override func mouseUp(with event: NSEvent) {
        if !didDrag {
            (NSApp.delegate as? AppDelegate)?.triggerKirbyInhale()
        }
    }

    override func rightMouseDown(with event: NSEvent) {
        if let menu = self.menu {
            NSMenu.popUpContextMenu(menu, with: event, for: self)
        }
    }
}

/// Full-screen transparent overlay that renders the suction vortex, wind streaks, and flying stars
final class SuctionVortexOverlayController {
    private var overlayWindow: NSWindow?

    func playSuctionVortex(toward mouthScreenPoint: NSPoint, on screen: NSScreen) {
        overlayWindow?.orderOut(nil)

        let screenFrame = screen.frame
        let win = NSWindow(
            contentRect: screenFrame,
            styleMask: .borderless,
            backing: .buffered,
            defer: false
        )
        win.isOpaque = false
        win.backgroundColor = .clear
        win.ignoresMouseEvents = true
        win.hasShadow = false
        win.level = NSWindow.Level(rawValue: NSWindow.Level.floating.rawValue - 1)
        win.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .stationary]

        let rootView = NSView(frame: NSRect(origin: .zero, size: screenFrame.size))
        rootView.wantsLayer = true
        rootView.layer?.backgroundColor = NSColor.clear.cgColor
        win.contentView = rootView
        win.orderFrontRegardless()
        self.overlayWindow = win

        guard let rootLayer = rootView.layer else { return }
        let target = CGPoint(
            x: mouthScreenPoint.x - screenFrame.minX,
            y: mouthScreenPoint.y - screenFrame.minY
        )

        // 1. Pulsing suction rings collapsing into Kirby's mouth
        for i in 0..<5 {
            let ringRadius: CGFloat = 210
            let ring = CAShapeLayer()
            ring.bounds = CGRect(x: 0, y: 0, width: ringRadius * 2, height: ringRadius * 2)
            ring.position = target
            ring.path = CGPath(ellipseIn: ring.bounds, transform: nil)
            ring.fillColor = NSColor.clear.cgColor
            ring.strokeColor = NSColor(calibratedRed: 1.0, green: 0.85, blue: 0.95, alpha: 0.75).cgColor
            ring.lineWidth = 3.5
            ring.lineDashPattern = [18, 12]
            ring.opacity = 0
            rootLayer.addSublayer(ring)

            let delay = CACurrentMediaTime() + Double(i) * 0.13
            let scaleAnim = CABasicAnimation(keyPath: "transform.scale")
            scaleAnim.fromValue = 1.4
            scaleAnim.toValue = 0.05
            scaleAnim.duration = 0.55
            scaleAnim.beginTime = delay
            scaleAnim.timingFunction = CAMediaTimingFunction(name: .easeIn)

            let rotAnim = CABasicAnimation(keyPath: "transform.rotation.z")
            rotAnim.fromValue = 0
            rotAnim.toValue = CGFloat.pi * 1.5
            rotAnim.duration = 0.55
            rotAnim.beginTime = delay

            let fadeAnim = CAKeyframeAnimation(keyPath: "opacity")
            fadeAnim.values = [0.0, 0.85, 0.0]
            fadeAnim.keyTimes = [0.0, 0.3, 1.0]
            fadeAnim.duration = 0.55
            fadeAnim.beginTime = delay

            ring.add(scaleAnim, forKey: "scale")
            ring.add(rotAnim, forKey: "rot")
            ring.add(fadeAnim, forKey: "fade")
        }

        // 2. Curved wind streaks rushing from across the screen into Kirby's mouth
        let streakCount = 34
        for i in 0..<streakCount {
            let angle = (CGFloat(i) / CGFloat(streakCount)) * CGFloat.pi * 2.0 + CGFloat.random(in: -0.15...0.15)
            let startDist = CGFloat.random(in: 220...max(screenFrame.width, screenFrame.height) * 0.75)
            let startPt = CGPoint(
                x: target.x + cos(angle) * startDist,
                y: target.y + sin(angle) * startDist
            )
            // Control point offset perpendicular to line for a swirling vortex curve
            let midDist = startDist * 0.48
            let swirlAngle = angle + (i.isMultiple(of: 2) ? 0.42 : -0.42)
            let ctrlPt = CGPoint(
                x: target.x + cos(swirlAngle) * midDist,
                y: target.y + sin(swirlAngle) * midDist
            )

            let path = CGMutablePath()
            path.move(to: startPt)
            path.addQuadCurve(to: target, control: ctrlPt)

            let streak = CAShapeLayer()
            streak.path = path
            streak.fillColor = NSColor.clear.cgColor
            let isPink = i.isMultiple(of: 3)
            streak.strokeColor = (isPink
                ? NSColor(calibratedRed: 1.0, green: 0.72, blue: 0.88, alpha: 0.9)
                : NSColor(calibratedWhite: 1.0, alpha: 0.88)).cgColor
            streak.lineWidth = CGFloat.random(in: 2.2...4.5)
            streak.lineCap = .round
            streak.strokeStart = 0.0
            streak.strokeEnd = 0.0
            rootLayer.addSublayer(streak)

            let delay = CACurrentMediaTime() + Double.random(in: 0.0...0.38)
            let dur = Double.random(in: 0.36...0.52)

            let endAnim = CABasicAnimation(keyPath: "strokeEnd")
            endAnim.fromValue = 0.0
            endAnim.toValue = 1.0
            endAnim.duration = dur * 0.65
            endAnim.beginTime = delay
            endAnim.timingFunction = CAMediaTimingFunction(name: .easeIn)
            endAnim.fillMode = .forwards
            endAnim.isRemovedOnCompletion = false

            let startAnim = CABasicAnimation(keyPath: "strokeStart")
            startAnim.fromValue = 0.0
            startAnim.toValue = 1.0
            startAnim.duration = dur * 0.75
            startAnim.beginTime = delay + dur * 0.25
            startAnim.timingFunction = CAMediaTimingFunction(name: .easeIn)
            startAnim.fillMode = .forwards
            startAnim.isRemovedOnCompletion = false

            streak.add(endAnim, forKey: "strokeEnd")
            streak.add(startAnim, forKey: "strokeStart")
        }

        // 3. Golden 5-pointed Kirby stars spiraling from all over the screen into Kirby's mouth
        let starCount = 26
        for i in 0..<starCount {
            let starRadius = CGFloat.random(in: 14...28)
            let starLayer = makeStarLayer(radius: starRadius)

            // Spawn stars across the entire screen
            let startX = CGFloat.random(in: 60...(screenFrame.width - 60))
            let startY = CGFloat.random(in: 60...(screenFrame.height - 60))
            let startPt = CGPoint(x: startX, y: startY)
            starLayer.position = startPt
            starLayer.opacity = 0
            rootLayer.addSublayer(starLayer)

            let dx = startPt.x - target.x
            let dy = startPt.y - target.y
            let baseDist = hypot(dx, dy)
            let baseAngle = atan2(dy, dx)

            // Build a spiral path into Kirby's mouth
            let path = CGMutablePath()
            path.move(to: startPt)
            let steps = 16
            let spinDir: CGFloat = i.isMultiple(of: 2) ? 1.0 : -1.0
            for s in 1...steps {
                let t = CGFloat(s) / CGFloat(steps)
                let r = baseDist * pow(1.0 - t, 1.35)
                let theta = baseAngle + spinDir * t * CGFloat.pi * 1.15
                let pt = CGPoint(x: target.x + cos(theta) * r, y: target.y + sin(theta) * r)
                path.addLine(to: pt)
            }

            let delay = CACurrentMediaTime() + Double.random(in: 0.0...0.26)
            let dur = Double.random(in: 0.48...0.68)

            let posAnim = CAKeyframeAnimation(keyPath: "position")
            posAnim.path = path
            posAnim.duration = dur
            posAnim.beginTime = delay
            posAnim.timingFunction = CAMediaTimingFunction(name: .easeIn)
            posAnim.fillMode = .forwards
            posAnim.isRemovedOnCompletion = false

            let scaleAnim = CAKeyframeAnimation(keyPath: "transform.scale")
            scaleAnim.values = [0.4, 1.25, 0.9, 0.05]
            scaleAnim.keyTimes = [0.0, 0.2, 0.7, 1.0]
            scaleAnim.duration = dur
            scaleAnim.beginTime = delay
            scaleAnim.fillMode = .forwards
            scaleAnim.isRemovedOnCompletion = false

            let rotAnim = CABasicAnimation(keyPath: "transform.rotation.z")
            rotAnim.fromValue = 0
            rotAnim.toValue = spinDir * CGFloat.pi * 4.0
            rotAnim.duration = dur
            rotAnim.beginTime = delay

            let opacityAnim = CAKeyframeAnimation(keyPath: "opacity")
            opacityAnim.values = [0.0, 1.0, 1.0, 0.0]
            opacityAnim.keyTimes = [0.0, 0.12, 0.88, 1.0]
            opacityAnim.duration = dur
            opacityAnim.beginTime = delay
            opacityAnim.fillMode = .forwards
            opacityAnim.isRemovedOnCompletion = false

            starLayer.add(posAnim, forKey: "pos")
            starLayer.add(scaleAnim, forKey: "scale")
            starLayer.add(rotAnim, forKey: "rot")
            starLayer.add(opacityAnim, forKey: "opacity")
        }
    }

    /// Plays a little celebratory star burst around Kirby when he finishes gulping
    func playGulpStarBurst(at mouthScreenPoint: NSPoint, on screen: NSScreen) {
        guard let rootLayer = overlayWindow?.contentView?.layer else { return }
        let screenFrame = screen.frame
        let center = CGPoint(
            x: mouthScreenPoint.x - screenFrame.minX,
            y: mouthScreenPoint.y - screenFrame.minY
        )

        let burstCount = 8
        for i in 0..<burstCount {
            let angle = (CGFloat(i) / CGFloat(burstCount)) * CGFloat.pi * 2.0
            let star = makeStarLayer(radius: 13)
            star.position = center
            rootLayer.addSublayer(star)

            let endPt = CGPoint(
                x: center.x + cos(angle) * 95,
                y: center.y + sin(angle) * 95
            )

            let posAnim = CABasicAnimation(keyPath: "position")
            posAnim.fromValue = center
            posAnim.toValue = endPt
            posAnim.duration = 0.38
            posAnim.timingFunction = CAMediaTimingFunction(name: .easeOut)
            posAnim.fillMode = .forwards
            posAnim.isRemovedOnCompletion = false

            let scaleAnim = CAKeyframeAnimation(keyPath: "transform.scale")
            scaleAnim.values = [0.3, 1.15, 0.0]
            scaleAnim.keyTimes = [0.0, 0.4, 1.0]
            scaleAnim.duration = 0.38
            scaleAnim.fillMode = .forwards
            scaleAnim.isRemovedOnCompletion = false

            star.add(posAnim, forKey: "burstPos")
            star.add(scaleAnim, forKey: "burstScale")
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) { [weak self] in
            self?.overlayWindow?.orderOut(nil)
            self?.overlayWindow = nil
        }
    }

    private func makeStarLayer(radius: CGFloat) -> CAShapeLayer {
        let layer = CAShapeLayer()
        layer.bounds = CGRect(x: 0, y: 0, width: radius * 2, height: radius * 2)
        let path = CGMutablePath()
        let cx = radius
        let cy = radius
        let innerRadius = radius * 0.44
        for i in 0..<10 {
            let angle = (CGFloat(i) * .pi / 5.0) + (.pi / 2.0)
            let r = i.isMultiple(of: 2) ? radius : innerRadius
            let pt = CGPoint(x: cx + cos(angle) * r, y: cy + sin(angle) * r)
            if i == 0 {
                path.move(to: pt)
            } else {
                path.addLine(to: pt)
            }
        }
        path.closeSubpath()
        layer.path = path
        layer.fillColor = NSColor(calibratedRed: 1.0, green: 0.90, blue: 0.25, alpha: 1.0).cgColor
        layer.strokeColor = NSColor(calibratedRed: 0.95, green: 0.55, blue: 0.10, alpha: 1.0).cgColor
        layer.lineWidth = 2.0
        layer.shadowColor = NSColor(calibratedRed: 1.0, green: 0.85, blue: 0.2, alpha: 1.0).cgColor
        layer.shadowOpacity = 0.85
        layer.shadowRadius = 6.0
        layer.shadowOffset = .zero
        return layer
    }
}

final class FloatingPetWindow: NSWindow {
    override var canBecomeKey: Bool { true }
    override var canBecomeMain: Bool { false }
}

final class AppDelegate: NSObject, NSApplicationDelegate {
    private var window: FloatingPetWindow!
    private var kirbyView: KirbyView!
    private var statusItem: NSStatusItem?
    private var currentSize: CGFloat = 150
    private let vortexController = SuctionVortexOverlayController()

    private func loadResourceImage(named name: String) -> NSImage? {
        let scriptDir = URL(fileURLWithPath: #filePath).deletingLastPathComponent()
        let adjacentPath = scriptDir.appendingPathComponent("\(name).png").path
        if let loaded = NSImage(contentsOfFile: adjacentPath) {
            return loaded
        }
        if let bundlePath = Bundle.main.path(forResource: name, ofType: "png"),
           let loaded = NSImage(contentsOfFile: bundlePath) {
            return loaded
        }
        return NSImage(contentsOfFile: "\(name).png")
    }

    func applicationDidFinishLaunching(_ notification: Notification) {
        let normalImage = loadResourceImage(named: "kirby") ?? NSImage(size: NSSize(width: 150, height: 150))
        let inhaleImage = loadResourceImage(named: "kirby_inhale") ?? normalImage

        let screenFrame = NSScreen.main?.visibleFrame ?? NSRect(x: 0, y: 0, width: 1200, height: 800)
        let initialRect = NSRect(
            x: screenFrame.maxX - currentSize - 48,
            y: screenFrame.minY + 48,
            width: currentSize,
            height: currentSize
        )

        window = FloatingPetWindow(
            contentRect: initialRect,
            styleMask: .borderless,
            backing: .buffered,
            defer: false
        )
        window.isOpaque = false
        window.backgroundColor = .clear
        window.hasShadow = true
        window.level = .floating
        window.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .stationary]
        window.isMovableByWindowBackground = false

        kirbyView = KirbyView(
            frame: NSRect(origin: .zero, size: initialRect.size),
            normalImage: normalImage,
            inhaleImage: inhaleImage
        )
        kirbyView.menu = buildMenu()

        window.contentView = kirbyView
        window.makeKeyAndOrderFront(nil)

        setupStatusItem(image: normalImage, menu: buildMenu())
    }

    private func setupStatusItem(image: NSImage, menu: NSMenu) {
        let item = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        if let button = item.button {
            let icon = image.copy() as! NSImage
            icon.size = NSSize(width: 18, height: 18)
            button.image = icon
            button.toolTip = "Kirby Desktop Pet"
        }
        item.menu = menu
        self.statusItem = item
    }

    private func buildMenu() -> NSMenu {
        let menu = NSMenu()

        let clearItem = NSMenuItem(
            title: "Inhale All Windows",
            action: #selector(hideAllWindowsAction),
            keyEquivalent: ""
        )
        clearItem.target = self
        menu.addItem(clearItem)

        let bounceItem = NSMenuItem(
            title: "Toggle Idle Bounce",
            action: #selector(toggleBounceAction),
            keyEquivalent: ""
        )
        bounceItem.target = self
        menu.addItem(bounceItem)

        menu.addItem(.separator())

        let sizeMenu = NSMenu()
        for (label, size) in [("Small", 110.0), ("Medium", 150.0), ("Large", 210.0)] {
            let item = NSMenuItem(
                title: label,
                action: #selector(changeSizeAction(_:)),
                keyEquivalent: ""
            )
            item.target = self
            item.representedObject = CGFloat(size)
            sizeMenu.addItem(item)
        }
        let sizeParent = NSMenuItem(title: "Size", action: nil, keyEquivalent: "")
        sizeParent.submenu = sizeMenu
        menu.addItem(sizeParent)

        menu.addItem(.separator())

        let quitItem = NSMenuItem(
            title: "Quit Kirby",
            action: #selector(quitAction),
            keyEquivalent: "q"
        )
        quitItem.target = self
        menu.addItem(quitItem)

        return menu
    }

    @objc private func hideAllWindowsAction() {
        triggerKirbyInhale()
    }

    func triggerKirbyInhale() {
        let screen = window.screen ?? NSScreen.main ?? NSScreen.screens.first!
        let mouthPt = kirbyView.mouthScreenPoint()

        vortexController.playSuctionVortex(toward: mouthPt, on: screen)
        kirbyView.playInhaleSequence(
            onMidInhale: { [weak self] in
                self?.hideAllWindows()
            },
            onComplete: { [weak self] in
                guard let self = self else { return }
                self.vortexController.playGulpStarBurst(at: self.kirbyView.mouthScreenPoint(), on: screen)
            }
        )
    }

    @objc private func toggleBounceAction() {
        kirbyView.isBouncingEnabled.toggle()
    }

    @objc private func changeSizeAction(_ sender: NSMenuItem) {
        guard let newSize = sender.representedObject as? CGFloat else { return }
        currentSize = newSize
        var frame = window.frame
        let center = NSPoint(x: frame.midX, y: frame.midY)
        frame.size = NSSize(width: newSize, height: newSize)
        frame.origin = NSPoint(x: center.x - newSize / 2, y: center.y - newSize / 2)
        window.setFrame(frame, display: true, animate: true)
    }

    @objc private func quitAction() {
        NSApp.terminate(nil)
    }

    func hideAllWindows() {
        NSApp.activate(ignoringOtherApps: true)
        NSWorkspace.shared.hideOtherApplications()

        let currentPID = ProcessInfo.processInfo.processIdentifier
        for app in NSWorkspace.shared.runningApplications {
            if app.processIdentifier != currentPID && app.activationPolicy == .regular {
                app.hide()
            }
        }

        let finderRunning = NSWorkspace.shared.runningApplications.contains {
            $0.bundleIdentifier == "com.apple.finder"
        }
        if finderRunning {
            DispatchQueue.global(qos: .userInitiated).async {
                let script = NSAppleScript(source: """
                tell application "Finder"
                    try
                        set collapsed of every window to true
                    end try
                end tell
                """)
                var errorDict: NSDictionary? = nil
                script?.executeAndReturnError(&errorDict)
            }
        }
    }
}

let app = NSApplication.shared
let delegate = AppDelegate()
app.delegate = delegate
app.setActivationPolicy(.accessory)
app.run()
